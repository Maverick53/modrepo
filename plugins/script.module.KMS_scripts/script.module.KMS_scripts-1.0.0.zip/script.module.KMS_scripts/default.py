# -*- coding: utf-8 -*-

import sys
from lib.modules._addon import *
from lib.scripts import setting_scripts
from lib.scripts import autoplay_scripts

if not setting_true('debug') and setting_true_km('debug'):
	setting_set('debug','true')
elif setting_true('debug') and not setting_true_km('debug'):
	setting_set('debug','false')

def main():
	if len(sys.argv) >= 2:
		mode = int(sys.argv[2])
		channel = None
		start = None
		epg_country = None
		service_name = None
		if sys.argv[1] == 'setting_script':
			setting_scripts.SettingScripts(mode)
		elif sys.argv[1] == 'autoplay_script':
			if len(sys.argv) >=3:
				channel = sys.argv[3]
			if len(sys.argv) >=4:
				start = sys.argv[4]
			if len(sys.argv) >=5:
				epg_country = sys.argv[5]
			if len(sys.argv) >=6:
				service_name = sys.argv[6]
			autoplay_scripts.AutoPlay(mode,channel,start,epg_country,service_name)
		else:
			Log('invalid script {}'.format(sys.argv[1]))
	else:
		Log('Len of sys.argv incorrect {} items'.format(len(sys.argv))) 




if __name__ == '__main__':
	main()