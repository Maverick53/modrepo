import xbmcaddon

MainBase = 'https://pastebin.com/raw/jdT7h7WL'
addon = xbmcaddon.Addon('plugin.video.rd')