import os
import xbmc
import xbmcaddon

from lib.modules._common import *

#SCRIPT ADDON
addon           = xbmcaddon.Addon()
addoninfo       = addon.getAddonInfo
setting         = addon.getSetting
setting_true    = lambda x: bool(True if setting(str(x)) == "true" else False)
setting_set     = addon.setSetting

addon_version   = addoninfo('version')
addon_name      = addoninfo('name')
addon_id        = addoninfo('id')
addon_icon      = addoninfo("icon")
addon_fanart    = addoninfo("fanart")
addon_path      = TranslatePath(addon_id,'path')
addon_profile   = TranslatePath(addon_id,'profile')

#KONG MEDIA ADDON
addon_km              = xbmcaddon.Addon('plugin.video.kongmedia') if HasAddon('plugin.video.kongmedia') else None
addon_km_info         = addon_km.getAddonInfo
setting_km            = addon_km.getSetting
setting_true_km       = lambda x: bool(True if setting_km(str(x)) == "true" else False)
setting_set_km        = addon_km.setSetting
addon_km_path         = TranslatePath('plugin.video.kongmedia','path')
addon_km_profile      = TranslatePath('plugin.video.kongmedia','profile')
addon_km_backup       = os.path.join(addon_km_profile,'backup')
addon_km_usersettings = os.path.join(addon_km_profile,'settings.xml')
epg_folder            = os.path.join(addon_km_profile,'epg')
uk_epg_folder         = os.path.join(epg_folder,'uk_epg')
us_epg_folder         = os.path.join(epg_folder,'us_epg')
es_epg_folder         = os.path.join(epg_folder,'es_epg')

UK_EPG_ZIP         = os.path.join(uk_epg_folder,'UK_guide.gz')
US_EPG_ZIP 		   = os.path.join(us_epg_folder,'US_guide.gz')
UK_EPG_XML         = os.path.join(uk_epg_folder,'UK_guide.xml')
GOLD_UK_EPG_XML    = os.path.join(uk_epg_folder,'gold_UK_guide.xml')
GREEN_UK_EPG_XML   = os.path.join(uk_epg_folder,'green_UK_guide.xml')
RED_UK_EPG_XML     = os.path.join(uk_epg_folder,'red_UK_guide.xml')
US_EPG_XML         = os.path.join(us_epg_folder,'US_guide.xml')
GOLD_US_EPG_XML    = os.path.join(us_epg_folder,'gold_US_guide.xml')
GREEN_US_EPG_XML   = os.path.join(us_epg_folder,'green_US_guide.xml')
RED_US_EPG_XML     = os.path.join(us_epg_folder,'red_US_guide.xml')
GOLD_ES_EPG_XML    = os.path.join(es_epg_folder,'gold_ES_guide.xml')
GREEN_ES_EPG_XML   = os.path.join(es_epg_folder,'green_ES_guide.xml')
RED_ES_EPG_XML     = os.path.join(es_epg_folder,'red_ES_guide.xml')
GOLD_UK_CHANNELS   = os.path.join(uk_epg_folder,'gold_uk_channels.xml')
GREEN_UK_CHANNELS  = os.path.join(uk_epg_folder,'green_uk_channels.xml')
RED_UK_CHANNELS    = os.path.join(uk_epg_folder,'red_uk_channels.xml')
GOLD_US_CHANNELS   = os.path.join(us_epg_folder,'gold_us_channels.xml')
GREEN_US_CHANNELS  = os.path.join(us_epg_folder,'green_us_channels.xml')
RED_US_CHANNELS    = os.path.join(us_epg_folder,'red_us_channels.xml')
GOLD_UK_EPG_DB     = os.path.join(uk_epg_folder,'gold_source.db')
GOLD_US_EPG_DB     = os.path.join(us_epg_folder,'gold_source.db')
GOLD_ES_EPG_DB     = os.path.join(es_epg_folder,'gold_source.db')
GREEN_UK_EPG_DB    = os.path.join(uk_epg_folder,'green_source.db')
GREEN_US_EPG_DB    = os.path.join(us_epg_folder,'green_source.db')
GREEN_ES_EPG_DB    = os.path.join(es_epg_folder,'green_source.db')
RED_UK_EPG_DB      = os.path.join(uk_epg_folder,'red_source.db')
RED_US_EPG_DB      = os.path.join(us_epg_folder,'red_source.db')
RED_ES_EPG_DB      = os.path.join(es_epg_folder,'red_source.db')
GOLD_EPG_XML       = os.path.join(epg_folder,'gold_xmltv.xml')
GREEN_EPG_XML      = os.path.join(epg_folder,'green_xmltv.xml')
RED_EPG_XML        = os.path.join(epg_folder,'red_xmltv.xml')

gold_host  = AddonSetting('plugin.video.kongmedia','goldhost')
gold_port  = AddonSetting('plugin.video.kongmedia','goldport')
green_host = AddonSetting('plugin.video.kongmedia','greenhost')
green_port = AddonSetting('plugin.video.kongmedia','greenport')
red_host   = AddonSetting('plugin.video.kongmedia','redhost')
red_port   = AddonSetting('plugin.video.kongmedia','redport')

#EXTENDED INFO ADDON
if HasAddon('script.extendedinfo'):
	addon_ext         = xbmcaddon.Addon('script.extendedinfo')
	addon_ext_info    = addon_ext.getAddonInfo
	setting_ext       = addon_ext.getSetting
	setting_true_ext  = lambda x: bool(True if setting_ext(str(x)) == "true" else False)
	setting_set_ext   = addon_ext.setSetting
	addon_ext_path    = TranslatePath('script.extendedinfo','path')
	addon_ext_profile = TranslatePath('script.extendedinfo','profile')

USERDATA    = xbmc.translatePath('special://userdata').decode('utf-8')
HOME_FOLDER = xbmc.translatePath('special://home')
LOGPATH     = xbmc.translatePath('special://logpath')
FAVOURITES  = os.path.join(USERDATA,'favourites.xml')
LOGFILE     = os.path.join(LOGPATH,'kodi.log')
LOGFILE_OLD = os.path.join(LOGPATH,'kodi.old.log')