# -*- coding: utf-8 -*-
import requests

from lib.modules._addon import *
from lib.modules._common import *


def CheckAccount(service_name):
	data = GetEpg(service_name)
	userinfo = data.get('user_info')
	auth = userinfo.get('auth')
	if int(auth) == 1:
		Log('Login Check OK')
		return True
	else:
		Log('Login Check Failed')
		return False

def GetEpg(service_name):
	base_url = GetHostPort(service_name)
	url = '{}/panel_api.php?username={}&password={}'.format(base_url,setting_km(str(service_name)+'username'),setting_km(str(service_name)+'password'))
	r = requests.get(url)
	data = r.json()
	return data

def GetEpgChannels(service_name,channeltype):
	livelist = []
	count = 0
	if CheckAccount(service_name):
		data = GetEpg(service_name)
		channels = data.get("available_channels")
		for channel in channels:
			channeldata = data.get("available_channels").get(str(channel))
			if channeldata.get('stream_type') == channeltype:
				count += 1
				name= channeldata.get('name')
				streamid= channeldata.get("stream_id")
				category_name = channeldata.get('category_name')
				epg_channel_id =  channeldata.get('epg_channel_id')
				livelist.append({'name':name,'streamid':streamid,'category_name':category_name,'epg_channel_id':epg_channel_id})
		return livelist,count

def GetHostPort(service_name):
	Log('{}_host'.format(service_name))
	host = eval('{}_host'.format(service_name))
	port = eval('{}_port'.format(service_name))
	return '{}:{}'.format(host,port)


def GetXmlTv(service_name):
	Log('Getting panel xmltv file for service {}'.format(service_name))
	base_url = GetHostPort(service_name)
	url = '{}/xmltv.php?username={}&password={}'.format(base_url,setting_km(str(service_name)+'username'),setting_km(str(service_name)+'password'))
	dst_file = eval('{}_EPG_XML'.format(service_name.upper()))
	DownloadFile(url,dst_file)