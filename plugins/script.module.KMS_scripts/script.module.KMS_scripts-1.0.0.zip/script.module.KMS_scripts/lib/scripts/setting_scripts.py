# -*- coding: utf-8 -*-
import difflib
import fnmatch
import os
import shutil
import xbmcgui
import xml.etree.ElementTree as ET
from lib.modules import panelcalls
from lib.modules._addon import *
from lib.modules._common import *

class SettingScripts(object):
	def __init__(self,mode):
		self.Services = ['gold','red','green']
		self.Epgs     = ['EpgUk','EpgUs','EpgEs']
		self.ServerList = [gold_host,green_host,red_host]
		self.MyServices = self.MyServices()
		self.MyEpgList  = self.MyEpgList()
		self.dialog = xbmcgui.Dialog()
		self.Mode = mode
		self._RunMode(self.Mode)

	def _RunMode(self,Mode):
		if Mode==0:
			DelAllContents(epg_folder)
			if int(setting_km('getepgdata')) == 0:
				self.YnToClose(msg='Settings indicate that Kodi is required to restart to re-write EPG Data, Do You wish to Close?')
		elif Mode==1:
			self.ExtInfoPushSettings()
		elif Mode==2:
			InstallAddon('script.extendedinfo')
		elif Mode==3:
			OpenSettings('script.extendedinfo')
		elif Mode==4:
			self.ForceUpdateEpg('gold','uk')
		elif Mode==5:
			self.ForceUpdateEpg('green','uk')
		elif Mode==6:
			self.ForceUpdateEpg('red','uk')
		elif Mode==7:
			self.ForceUpdateEpg('gold','us')
		elif Mode==8:
			self.ForceUpdateEpg('green','us')
		elif Mode==9:
			self.ForceUpdateEpg('red','us')
		elif Mode==10:
			self.Clearlist(table='autoplays')
		elif Mode==11:
			self.Clearlist(table='notifications')
		elif Mode==12:
			self.LogViewer()
		elif Mode==13:
			self.SettingXmlBackup()
		elif Mode==14:
			self.SettingXmlRestore()
		elif Mode==15:
			DelAllContents(addon_km_backup)
		elif Mode==16:
			self.SaveLogFile()
		elif Mode==17:
			self.DefaultHostSettings()
		elif Mode==18:
			self.EditFavourites()
		else:
			self.Close(msg='No Mode found')

	def EditFavourites(self):
		l=list()
		tree = ET.parse(FAVOURITES)
		favourites = tree.getroot()
		for favourite in favourites:
			if 'plugin.video.kongmedia' in favourite.text or any(x in favourite.text for x in self.ServerList):
				itemList = xbmcgui.ListItem(label=favourite.get('name'),path=favourite.text)
				itemList.setArt({'icon':favourite.get('thumb')})
				l.append(itemList)
		ret = self.dialog.select('Select Favourite to modify/Remove',l)
		sel_path =l[ret].getPath()
		sel_label = l[ret].getLabel()
		sel_icon = l[ret].getArt('icon')
		if ret != -1:
			ret2 = self.dialog.select('modification of Favourite required',['Remove','Rename'])
			if ret2==0:
				for favourite in favourites:
					if favourite.text == sel_path:
						favourites.remove(favourite)
						tree.write(FAVOURITES)
			elif ret2==1:
				ret3=KeyBoard('Edit label',default=sel_label)
				for favourite in favourites:
					if favourite.text == sel_path:
						favourite.set('name',ret3)
						tree.write(FAVOURITES)
			else:
				Log('modification selection not recognised')
		else:
			Log('Select Favourite to modify/Remove cancelled')


	def DefaultHostSettings(self):
		for service,t in [(service,t) for service in self.MyServices for t in ['host','port']]:
			s=str(service+t)
			d=AddonSettingDefault('plugin.video.kongmedia',s)
			setting_set_km(s,d)
		
	def SaveLogFile(self):
		ret = self.dialog.browse(0, heading='Select destination to save log files',shares='files',defaultt='')
		logfilename = '{}_kodi.log'.format(DateTimeStrf(DateTimeNow(),'%Y%m%d%H%M'))
		oldlogfilename = '{}_kodi.old.log'.format(DateTimeStrf(DateTimeNow(),'%Y%m%d%H%M'))
		if ret:
			CopyFile(LOGFILE,os.path.join(ret,logfilename))
			CopyFile(LOGFILE_OLD,os.path.join(ret,oldlogfilename))

	def SettingXmlRestore(self):
		if PathExists(addon_km_backup):
			backups = list()
			if len(os.listdir(addon_km_backup)) > 0:
				for file in os.listdir(addon_km_backup):
					if fnmatch.fnmatch(file, '*_settings.xml'):
						backups.append(file)
				ret = self.dialog.select('Select file to restore',backups)
				CopyFile(os.path.join(addon_km_backup,backups[ret]),addon_km_usersettings)
			else:
				ret = self.dialog.yesno(addon_name,'No backups created would you like to create?')
				if ret:
					self.SettingXmlBackup()
		else:
				ret = self.dialog.yesno(addon_name,'No backups created would you like to create?')
				if ret:
					self.SettingXmlBackup()


	def SettingXmlBackup(self):
		CreateDir(addon_km_backup)
		filename = '{}_settings.xml'.format(DateTimeStrf(DateTimeNow(),'%Y%m%d%H%M'))
		CopyFile(addon_km_usersettings,os.path.join(addon_km_backup,filename))
		Sleep(3)
		if PathExists(os.path.join(addon_km_backup,filename)):
			Notify(message='Settings Xml backed up')
			Log('settings xml back up created {}'.format(filename))
		else:
			Log('settings back up not created {}'.format(filename))

	def LogViewer(self):
		r = open(LOGFILE)
		text = r.read()
		self.dialog.textviewer(addon_name, text)

	def Clearlist(self,table):
		PATHS = list()
		empDB = 0
		#Clears all alarms and list from table
		for s in self.MyServices:
			s = s.upper()
			for e in self.MyEpgList:
				e = e[3:].upper()
				path = eval('{}_{}_EPG_DB'.format(s,e))
				if PathExists(path):
					PATHS.append(path)
					rows = dbReadRows(path,table)
					if len(rows) > 0:
						for row in rows:
							alarm_name = self.createAlarmClockName(row[1],row[3])
							xbmc.executebuiltin('CancelAlarm({}-start,True)'.format(alarm_name.encode('utf-8', 'replace')))
							xbmc.executebuiltin('CancelAlarm({}-stop,True)'.format(alarm_name.encode('utf-8', 'replace')))
							Log('{} Alarm cancelled'.format(alarm_name))
					DelTableCont(path,table)
		for PATH in PATHS:
			empDB += len(dbReadRows(PATH,table))
		if empDB == 0:
			Notify(message='{} Alarms & Lists cleared'.format(table.capitalize()))
			Log('{} Alarms & Lists cleared'.format(table.capitalize()))
		else:
			Log('{} Alarms & Lists NOT cleared'.format(table.capitalize()))

	def ExtInfoPushSettings(self):
		if HasAddon('script.extendedinfo'):
			setting_set_ext('tmdb_username',setting_km('tmdbuser'))
			setting_set_ext('tmdb_password',setting_km('tmdbpassword'))
			setting_set_ext('include_adults',setting_km('tmdbadult'))
			Sleep(5)
			if setting_km('tmdbuser')==setting_ext('tmdb_username') and setting_km('tmdbpassword')==setting_ext('tmdb_password') and setting_km('tmdbadult')==setting_ext('include_adults'):
				Notify(message='Settings [COLOR green]pushed[/COLOR] correctly',times=5000)
				Log('Settings pushed from KM to EXT INFO correctly')
			else:
				Notify(message='Settings [COLOR red]Not Pushed[/COLOR] correctly',times=5000)
				Log('Settings not pushed from KM to EXT INFO correctly')
		else:
			Notify(message='ExtenedInfo [COLOR red]not[/COLOR] installed')
			Log('script.extendedinfo not installed')
			
	def ForceUpdateEpg(self,service_name,country):
		epg_folder = eval('{}_epg_folder'.format(country.lower()))
		epg_file = eval('{}_EPG_XML'.format(country.upper()))
		CreateDir(epg_folder)
		panelcalls.GetXmlTv(service_name)
		Sleep(3)
		if PathExists(epg_file):
			Notify(message='{} EPG File Retrieved'.format(country.upper()),times=5000)
			self.CustomXMLTV(service_name,country,epg_file)
			Sleep(3)
			if PathExists(eval('{}_{}_EPG_XML'.format(service_name.upper(),country.upper()))) and PathExists(eval("{}_{}_CHANNELS".format(service_name.upper(),country.upper()))):
				Notify(message='Custom EPG created for {} {}'.format(service_name.capitalize(),country.upper()),times=5000)


	def MyServices(self):
		a = list()
		for Service in self.Services:
			if setting_true_km('{}enabled'.format(Service)):
				if Service not in a:
					a.append(Service)
		return a 

	def MyEpgList(self):
		i = list()
		for Epg in self.Epgs:
			if setting_true_km('{}'.format(Epg)):
				i.append(Epg)
		return i 

	def Close(self,msg='Closing Script'):
		Log(msg)
		sys.exit()

	def YnToClose(self,msg):
		ret = self.dialog.yesno(addon_name, msg)
		if ret:
			xbmc.executebuiltin('Quit')

	def CustomXMLTV(self,service_name,epg_country):
		streamMatch = list()
		buildxml = False
		dupid = list()
		progToremove = list()
		toRemove = list()
		chllist = list()
		xmltvfile = eval('{}_EPG_XML'.format(service_name.upper()))
		livelist,livelistcount = panelcalls.GetEpgChannels(service_name,channeltype='live')
		if xbmcvfs.exists(xmltvfile):
			f = FileWrapper(xmltvfile)
			tree = ET.parse(f)
			root = tree.getroot()
			for channels in root.findall('channel'):
				streamElem = ET.Element('stream')
				channels.append(streamElem)
				channel = channels.find('display-name')
				channeltext = channels.findtext('display-name')
				Id = channels.get('id')
				toRemove.append(channels)
				if channeltext.lower().startswith('{}:'.format(epg_country.lower())) or Id.lower().endswith('.{}'.format(epg_country.lower())) and Id not in dupid and len((filter(lambda channel: channel['epg_channel_id'] == Id, livelist)))>0:
					streamId = filter(lambda channel:channel['epg_channel_id'] == Id,livelist)[0]['streamid']
					Match = filter(lambda channel:channel['epg_channel_id'] == Id,livelist)
					playUrl = '{}:{}/live/{}/{}/{}.ts'.format(eval('{}_host'.format(service_name.lower())),eval('{}_port'.format(service_name.lower())),setting('{}username'.format(service_name.lower())),setting('{}password'.format(service_name.lower())),streamId)
					dupid.append(Id)
					if channels in toRemove:
						toRemove.remove(channels)
					if not Id in progToremove:
						progToremove.append(Id)
					new_displayname = clean_channelName(channeltext)
					channel.text = new_displayname
					streamElem.text = playUrl
					for items in Match:
						streamMatch.append(items)
			for chl in toRemove:
				root.remove(chl)
			for programmes in root.findall('programme'):
				if not programmes.get('channel') in progToremove:
					root.remove(programmes)
			tree.write(eval('{}_{}_EPG_XML'.format(service_name.upper(),epg_country.upper())),encoding='utf-8')

	def createAlarmClockName(self, programTitle, startTime):
		return 'kongmedia-{}-{}'.format(programTitle, startTime)