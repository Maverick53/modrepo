# -*- coding: utf-8 -*-
import sqlite3
import xbmc
import xbmcgui
from lib.modules._addon import *
from lib.modules._common import *


class AutoPlay(object):
	def __init__(self,mode,channel,start,epg_country,service_name):
		self.Mode = mode
		self.Channel = channel
		self.Start = start
		self.EpgCountry = epg_country
		self.ServiceName = service_name
		self.player = xbmc.Player()
		self._RunMode(self.Mode)

	def _RunMode(self,Mode):
		if Mode==1:
			self.AutoPlay_Start(self.Channel,self.Start,self.EpgCountry,self.ServiceName)
		elif Mode==2:
			self.AutoPlay_Stop(self.Channel,self.Start)
		else:
			Log('Mode not correct {}'.format(Mode))

	def AutoPlay_Start(self,Channel,Start,EpgCountry,ServiceName):
		db_path = eval('{}_{}_EPG_DB'.format(ServiceName.upper(),EpgCountry.upper()))
		try:
		    conn = sqlite3.connect(db_path, detect_types=sqlite3.PARSE_DECLTYPES)
		except Exception as detail:
		    Log("EXCEPTION: {}".format(detail))
		c = conn.cursor()
		c.execute('SELECT stream_url FROM custom_stream_url WHERE channel=?', (Channel,))
		row = c.fetchone()
		if not row :
		    c.execute('SELECT stream_url FROM channels WHERE id=?',(Channel,))
		    row = c.fetchone()
		if row:
			url = row[0]
			setting_set_km('playing.channel',Channel)
			setting_set_km('playing.start',Start)
			self.StreamPlay(Channel,url)

	def AutoPlay_Stop(self,Channel,Start):
		if self.player.isPlaying():
			if setting_km('playing.channel') != channel:
				self.Close(msg='AutoPlay Channel({}) not playing'.format(Channel))
			elif setting_km('playing.start') != start:
				self.Close(msg='AutoPlay Program not playing')
			setting_set_km('playing.channel','')
			setting_set_km('playing.start','')
			self.player.stop()
		else:
			self.Close(msg='Player not playing')


	def StreamPlay(self,label,url):
		listitem = xbmcgui.ListItem( label = label, path=url )
		self.player.play(url,listitem)

	def Close(self,msg='Closing Script'):
		Log(msg)
		sys.exit()